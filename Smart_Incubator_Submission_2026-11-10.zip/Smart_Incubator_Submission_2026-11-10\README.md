# AI-Powered Smart Poultry Incubator with Automated Fertility Detection for Enhanced Hatchability

This private system snapshot was packaged on November 10, 2026 from the current local project files. The packaging date is not a new firmware build or model training date.

## Included

- `Software/Mobile_App_Source/`: Flutter/Android source, application assets, and bundled fertility model.
- `Software/Android_APK/app-release.apk`: existing release-mode APK, version 1.0.0+1, retained from October 9, 2026.
- `Software/P4_Firmware/`: current ESP-IDF source, local components, configuration, and November 2 egg-counter model.
- `Software/P4_Prebuild/`: existing P4 application, bootloader, partition table, and flash arguments. These were copied, not rebuilt.
- `Software/S3_Camera/`: current ESP32-S3 camera/access-point sketch.
- `Software/Sub_Incubator/`: current climate sensor and relay sketch.
- `Software/LED_Controller/`: current 56-slot LED-controller sketch.
- `Hardware/Pin_Map.md`: source-defined GPIO assignments, not a physical wiring inspection.
- `VERSION_MANIFEST.json`: checksums and source/build provenance for this snapshot.

Screenshots, dataset/sample images, raw training data, IDE caches, training environments, obsolete captures, consent records, signing keys, and the separate ESP32-C6 slave firmware are excluded. The app's required icons and image resources are retained.

## Important Version Difference

The October 11 historical archive contains the August 31 P4 egg-counter model. This snapshot includes the later November 2 model:

`33153FA977AB1452C05A2E8ED148B9145F962A8B9C6055A77EC58B8C77449890`

The Android source, existing release APK, fertility model, and other controller sketches match their October 11 archived counterparts. The retained P4 application binary was generated on November 2, 2026; a successful local flash log is retained in the original workspace. This package does not establish the version used for every historical incubation trial or the current contents of every physical device.

## Responsibilities

The P4 runs egg-occupancy counting for the tray cells. The Android app runs the Fertile/Infertile CNN on occupied candling crops. P4 receives fertility verdicts; it does not run the fertility CNN or persist captured JPEG images in NVS.

## Build And Install Notes

- Android: use a compatible Flutter SDK, then `flutter pub get` and `flutter build apk --release` from `Software/Mobile_App_Source`. The project falls back to debug signing for a release-mode build when a private release keystore is unavailable. No signing key is included.
- P4 source: use the compatible ESP-IDF 5.5.x toolchain from `Software/P4_Firmware`. Dependencies are declared in `main/idf_component.yml`. Do not erase NVS or change the separate hosted slave firmware as part of this source update.
- P4 prebuilt files: the existing `flash_args` records the original ESP32-P4 addresses and flash settings. Confirm the exact board, serial port, flash size, and installed configuration before using any retained binary. This snapshot was not rebuilt or flashed during packaging.
- Arduino sketches: open the appropriate `.ino` using the matching ESP32 board package and sketch dependencies. A matching cached build is not proof of an upload to a particular device.

## Privacy And Safety

Keep the repository private: the firmware includes the system's local Wi-Fi configuration. No GitHub credentials or Android signing keys are part of this snapshot. Change device credentials consistently before any public redistribution.

Check actual wiring, power supply capacity, relay ratings, fuses, and mains isolation before powering or modifying the incubator. The pin map describes source settings only.
