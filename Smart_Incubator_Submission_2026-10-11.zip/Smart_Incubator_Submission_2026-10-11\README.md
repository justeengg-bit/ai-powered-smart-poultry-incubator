# AI-Powered Smart Poultry Incubator with Automated Fertility Detection for Enhanced Hatchability

This private submission contains the system source code, an Android APK, and hardware pin assignments. It excludes build caches, datasets, signing keys, and obsolete wiring diagrams.

## Contents

- `Software/Mobile_App_Source/`: Flutter/Android application source and bundled fertility model.
- `Software/Android_APK/app-release.apk`: the latest available release-mode Android build (October 9, 2026).
- `Software/P4_Firmware/`: ESP-IDF egg-counter firmware, its model, and local components.
- `Software/S3_Camera/`: ESP32-S3 camera and access-point sketch.
- `Software/Sub_Incubator/`: climate sensor and relay sketch.
- `Software/LED_Controller/`: 56-slot LED-controller sketch.
- `Hardware/Pin_Map.md`: GPIO assignments as configured in the included source.

## Build Notes

- Mobile app: from `Software/Mobile_App_Source`, run `flutter pub get` and `flutter build apk --release` with a compatible Flutter SDK and Android toolchain. The included APK was built from these app sources. Without a private release keystore, this Android project falls back to debug signing for a release-mode build.
- P4: from `Software/P4_Firmware`, use ESP-IDF 5.5.x and run `idf.py build`. Managed ESP-Hosted dependencies are declared in `main/idf_component.yml`; the separate ESP32-C6 hosted firmware is not included or modified here.
- S3, sub-incubator, and LED-controller sketches: open each `.ino` in Arduino IDE with the appropriate ESP32 board support and sketch dependencies.

## Sharing And Safety

The firmware contains the local `AI_CANDLING` Wi-Fi password. Keep this package and repository private, and change the password across all devices before sharing publicly. No Android signing key is included.

The pin map describes code settings, not a verified physical wiring inspection. Do not use legacy diagrams as a substitute for checking the actual wiring, power supply, relay ratings, fuse, and mains isolation.
